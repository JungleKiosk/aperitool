from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsPointXY
import csv

# 1. Ottieni il layer attivo
layer = iface.activeLayer()
if not layer or not layer.isValid():
    raise Exception("Nessun layer valido selezionato. Seleziona prima un layer nella legenda.")

# 2. Controlla che ci siano feature selezionate
selected = layer.selectedFeatures()
if not selected:
    raise Exception("Nessuna feature selezionata. Seleziona almeno un elemento nello shapefile.")

# 3. Imposta il CSV di output
csv_path = "C:/Users/.../output_py.csv"

# 4. Apri il CSV e scrivi l’intestazione
with open(csv_path, mode='w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["feature_id", "vertex_index", "x", "y"])

    # 5. Itera solo sulle feature selezionate
    for feat in selected:
        geom = feat.geometry()
        for idx, pt in enumerate(geom.vertices()):
            writer.writerow([feat.id(), idx, pt.x(), pt.y()])

print(f"Coordinate delle feature selezionate salvate in: {csv_path}")
